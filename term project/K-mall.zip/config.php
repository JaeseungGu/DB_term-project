﻿<?php
    $host = "localhost";
    $dbid = "mall";                    // 자신의 DB ID
    $dbpass = "mall";                  // 자신의 DB Password
    $dbname = "mall";                  // 해당 프로젝트에서 사용하는 DB명
?>
