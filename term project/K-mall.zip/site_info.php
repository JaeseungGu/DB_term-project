<? include ("header.php"); ?>
    <div class='container'>
        <h3>Welcome to K-mall !!!! </h3>
        <p>DB를 이용하는 간략한 web application 예제 사이트 입니다.</p>
        <p>본 예제 사이트의 테이블 관계도는 다음 그림과 같습니다.</p>
        <p><img src="images/table_rel.PNG"></p>
        <p>* Internet Explorer의 경우 호환성 보기 설정을 해제해 주십시오.</p>
    </div>
<? include ("footer.php"); ?>